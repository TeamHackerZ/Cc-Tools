<!DOCTYPE html>
<html>
<head>
	<title>𝗡𝗜𝗡𝗝𝗔 𝗦𝗞 𝗚𝗘𝗡𝗘𝗥𝗔𝗧𝗢𝗥</title>
	  <link rel="icon" type="image/png" href="./logo.png">
</head>
<body>
<span style="font-size: 14px;">Enter the Amount of SK Keys</span><br>
<span style="font-size: 4px;"> </span>
<form action='' method='POST'>
<input type="text" name="number">
<input type="submit" name="submit" value='generate'>
</form>
</body>
</html>



	


