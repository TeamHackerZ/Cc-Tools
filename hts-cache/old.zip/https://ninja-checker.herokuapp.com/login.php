<!DOCTYPE html>
<html>
<head>
	<title>Ninja Checker | Login</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  
</head>
<body>
	<img class="wave" src="img/wave.png">
	<div class="container">
		<div class="img">
			<img src="img/bg.svg">
		</div>
		<div class="login-content">
			<form method="POST" action="login_code.php">
				<img src="img/avatar.svg">
				<h2 class="title" style="font-size: 45px;">NINJA CHECKER</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<input type="username" class="form-control" name="username" id="username" placeholder="Username">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<input type="password" class="form-control" name="password" id="pwd" placeholder="Password">
            	   </div>
            	</div>
            	
            	  <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" name="login" class="btn">Login</button>
                </div>
               </div>
              <a href="Register.php">Don't Have a Account? Register Here</a>
            </form>
        </div>
    </div>
    <script type="text/javascript" src="js/main.js"></script>
</body>
</html>
